import firebase from "firebase/app";
import "firebase/auth";
import "firebase/database";

const prodConfig = {
  apiKey: "AIzaSyDMxTKwP6JVU_bLbGS_br4HwmMIUpuLCoI",
  authDomain: "fir-work-db-help.firebaseapp.com",
  databaseURL: "https://fir-work-db-help.firebaseio.com",
  projectId: "fir-work-db-help",
  storageBucket: "fir-work-db-help.appspot.com",
  messagingSenderId: "370440287336"
};
const devConfig = {
  apiKey: "AIzaSyD_DWIrzgmyOBQl5XzyVEYydtTVPZitjSE",
  authDomain: "fir-work-db.firebaseapp.com",
  databaseURL: "https://fir-work-db.firebaseio.com",
  projectId: "fir-work-db",
  storageBucket: "fir-work-db.appspot.com",
  messagingSenderId: "452335667577"
};

const config = process.env.NODE_ENV === "production" ? prodConfig : devConfig;

if (!firebase.apps.length) {
  firebase.initializeApp(config);
}

const db = firebase.database();
const auth = firebase.auth();

export { db, auth };
