export const USERS_SET = 'USERS_SET';
export const AUTH_USER_SET = 'AUTH_USER_SET';
export const ON_SAND_VALUE = 'ON_SAND_VALUE';
